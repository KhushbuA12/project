package com;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import com.DatabaseConnection;
import java.util.*;
import java.sql.*;


@WebServlet("/CompanyProfileServlet")
public class CompanyProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    
    private static final String UPLOAD_DIRECTORY = "uploads";
    int companyId = 123;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        List<Transaction> rupeeHistory = getRupeeHistoryFromDatabase(companyId); 
        
        request.setAttribute("rupeeHistory", rupeeHistory);
        request.getRequestDispatcher("rupee_history.jsp").forward(request, response);
        
         List<Job> appliedJobs = getAppliedJobsFromDatabase(companyId); 
        
        request.setAttribute("appliedJobs", appliedJobs);
        request.getRequestDispatcher("applied_jobs.jsp").forward(request, response);
    }
    private List<Job> getAppliedJobsFromDatabase(int studentId) {
        List<Job> appliedJobs = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection(); // Assuming you have a DatabaseConnection class to get the connection
            
            String sql = "SELECT * FROM applied_jobs WHERE student_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                // Create a Job object for each row in the result set
                Job job = new Job();
                job.setId(rs.getInt("job_id"));
                job.setRoleName(rs.getString("role_name"));
                job.setLocation(rs.getString("location"));
                job.setMinCtc(rs.getDouble("min_ctc"));
                job.setMaxCtc(rs.getDouble("max_ctc"));
                
                // Add the Job object to the list of applied jobs
                appliedJobs.add(job);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception
        } finally {
            // Close the resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        
        return appliedJobs;
    }
    private List<Transaction> getRupeeHistoryFromDatabase(int studentId) {
        List<Transaction> rupeeHistory = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            String sql = "SELECT * FROM rupee_transaction WHERE student_id = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
               
                Transaction transaction = new Transaction();
                transaction.setId(rs.getInt("id"));
                transaction.setAmount(rs.getDouble("amount"));
                transaction.setType(rs.getString("type"));
                transaction.setDate(rs.getTimestamp("date"));
                rupeeHistory.add(transaction);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle database exception
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
               
            }
        }
        
        return rupeeHistory;
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String companyName = request.getParameter("companyName");
        String website = request.getParameter("website");
        String teamSize = request.getParameter("teamSize");

        
        Part filePart = request.getPart("logo");
        String logoFileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        InputStream fileContent = filePart.getInputStream();

        
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        Path filePath = Paths.get(uploadPath, logoFileName);
        Files.copy(fileContent, filePath);

        try (Connection connection = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO companies (company_name, website, team_size, logo) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, companyName);
                statement.setString(2, website);
                statement.setString(3, teamSize);
                statement.setString(4, UPLOAD_DIRECTORY + File.separator + logoFileName);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("dashboard.jsp");
    }
}
