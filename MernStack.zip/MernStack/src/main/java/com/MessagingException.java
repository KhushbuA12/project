package com;

public class MessagingException extends Exception {

}
