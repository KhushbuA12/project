package com;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;
import javax.servlet.http.*;
import javax.servlet.http.HttpServlet.*;
import java.net.*;
import java.util.*;




@WebServlet("/JobServlet")
public class JobServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String roleName = request.getParameter("roleName");
        String location = request.getParameter("location");
        double minCTC = Double.parseDouble(request.getParameter("minCTC"));
        double maxCTC = Double.parseDouble(request.getParameter("maxCTC"));

        
        if (roleName == null || roleName.isEmpty() || location == null || location.isEmpty()) {
            
            response.sendRedirect("error.jsp");
            return;
        }

        
        double requiredRupees = 2 * roleName.length() + 5 * location.length();

        
        boolean hasSufficientBalance = checkCompanyBalance(requiredRupees); // Example method

        if (hasSufficientBalance) {
            
            deductCompanyBalance(requiredRupees); 

            
            storeJobPosting(roleName, location, minCTC, maxCTC); 

            
            sendEmailNotification("Job Posted", "Congratulations! Your job has been posted.");

           
            response.sendRedirect("dashboard.jsp");
        } else {
            
            response.sendRedirect("error.jsp");
        }
    }

    
    private boolean checkCompanyBalance(double requiredRupees) {
        
        return true; 
    }

    private void deductCompanyBalance(double requiredRupees) {
    	int companyId = getCurrentCompanyId();

        String query = "UPDATE companies SET balance = balance - ? WHERE id = ?";
        
        try {
        		Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:orcl","khushbu","khushbu");
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setDouble(1, requiredRupees);
                preparedStatement.setInt(2, companyId);
                preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int getCurrentCompanyId() {
        
        return 1; 
    }
  
    private void storeJobPosting(String roleName, String location, double minCTC, double maxCTC) {
    	    Connection conn = null;
    	    PreparedStatement pstmt = null;

    	    try {
    	        
    	        Class.forName("com.mysql.cj.jdbc.Driver");

    	        
    	        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/job_portal", "username", "password");

    	       
    	        String sql = "INSERT INTO jobs (role_name, location, min_ctc, max_ctc) VALUES (?, ?, ?, ?)";
    	        pstmt = conn.prepareStatement(sql);
    	        pstmt.setString(1, roleName);
    	        pstmt.setString(2, location);
    	        pstmt.setDouble(3, minCTC);
    	        pstmt.setDouble(4, maxCTC);

    	       
    	        pstmt.executeUpdate();
    	    } catch (ClassNotFoundException | SQLException e) {
    	        e.printStackTrace();
    	    } finally {
    	        
    	        try {
    	            if (pstmt != null) {
    	                pstmt.close();
    	            }
    	            if (conn != null) {
    	                conn.close();
    	            }
    	        } catch (SQLException e) {
    	            e.printStackTrace();
    	        }
    	    }
    }

    private void sendEmailNotification(String subject, String message) {
    	final String senderEmail = "your_email@example.com";
        final char[] senderPassword;

        
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.example.com");
        properties.put("mail.smtp.port", "587");

 }
}

