package com;

import java.io.IOException;
import java.util.*;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.Transaction;
import com.Job;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int studentId = 123;
        List<Job> appliedJobs = getAppliedJobsFromDatabase(studentId); 
        
        request.setAttribute("appliedJobs", appliedJobs);
        request.getRequestDispatcher("applied_jobs.jsp").forward(request, response);
        
        List<Transaction> rupeeHistory = getRupeeHistoryFromDatabase(studentId); 
        
        request.setAttribute("rupeeHistory", rupeeHistory);
        request.getRequestDispatcher("rupee_history.jsp").forward(request, response);
}
        private List<Job> getAppliedJobsFromDatabase(int studentId) {
            List<Job> appliedJobs = new ArrayList<>();
            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            try {
                conn = DatabaseConnection.getConnection(); // Assuming you have a DatabaseConnection class to get the connection
                
                String sql = "SELECT * FROM applied_jobs WHERE student_id = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setInt(1, studentId);
                rs = stmt.executeQuery();
                
                while (rs.next()) {
                    // Create a Job object for each row in the result set
                    Job job = new Job();
                    job.setId(rs.getInt("job_id"));
                    job.setRoleName(rs.getString("role_name"));
                    job.setLocation(rs.getString("location"));
                    job.setMinCtc(rs.getDouble("min_ctc"));
                    job.setMaxCtc(rs.getDouble("max_ctc"));
                    
                    // Add the Job object to the list of applied jobs
                    appliedJobs.add(job);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception
            } finally {
                // Close the resources
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            
            return appliedJobs;
        }
        private List<Transaction> getRupeeHistoryFromDatabase(int studentId) {
            List<Transaction> rupeeHistory = new ArrayList<>();
            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            try {
                conn = DatabaseConnection.getConnection();
                String sql = "SELECT * FROM rupee_transaction WHERE student_id = ?";
                stmt = conn.prepareStatement(sql);
                stmt.setInt(1, studentId);
                rs = stmt.executeQuery();
                
                while (rs.next()) {
                   
                    Transaction transaction = new Transaction();
                    transaction.setId(rs.getInt("id"));
                    transaction.setAmount(rs.getDouble("amount"));
                    transaction.setType(rs.getString("type"));
                    transaction.setDate(rs.getTimestamp("date"));
                    rupeeHistory.add(transaction);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle database exception
            } finally {
                // Close resources
                try {
                    if (rs != null) rs.close();
                    if (stmt != null) stmt.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                   
                }
            }
            
            return rupeeHistory;
        }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        
        if ("register".equals(action)) {
            registerStudent(request, response);
        } else if ("login".equals(action)) {
            loginStudent(request, response);
        }
    }
    
    private void registerStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String otp = generateOTP();
        
        
        HttpSession session = request.getSession();
        session.setAttribute("otp", otp);
        session.setAttribute("email", email);
        
        response.sendRedirect("verify_otp.jsp?type=student");
    }
    
    private void loginStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
       
        response.sendRedirect("dashboard.jsp?type=student");
       }
    
    private String generateOTP() {
       
        return "123456"; 
    }
}
