package com;

public class Job {
    private int id;
    private String roleName;
    private String location;
    private double minCtc;
    private double maxCtc;

    // Constructors, getters, and setters

    public Job() {
    }

    public Job(int id, String roleName, String location, double minCtc, double maxCtc) {
        this.id = id;
        this.roleName = roleName;
        this.location = location;
        this.minCtc = minCtc;
        this.maxCtc = maxCtc;
    }

    // Getters and setters for the attributes
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getMinCtc() {
        return minCtc;
    }

    public void setMinCtc(double minCtc) {
        this.minCtc = minCtc;
    }

    public double getMaxCtc() {
        return maxCtc;
    }

    public void setMaxCtc(double maxCtc) {
        this.maxCtc = maxCtc;
    }
}
