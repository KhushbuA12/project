package com;

public class InternetAddress {

	public InternetAddress(String senderEmail) {
		// TODO Auto-generated constructor stub
	}

	public static Object parse(Object recipientEmail) {
		// TODO Auto-generated method stub
		return null;
	}

}
